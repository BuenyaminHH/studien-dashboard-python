from student import Student
from semester import Semester

class Dashboard:
    """
    Dashboard zur Verwaltung der Semesterdaten und Anzeige von Fortschritt und Noten.
    """

    def __init__(self, student: Student):
        self.student = student
        self.semester = []
        self.klausurtermine = []  # Für manuell gesetzte Termine (z. B. Demo)

    def add_semester(self, semester: Semester):
        self.semester.append(semester)

    def calculate_notendurchschnitt(self):
        noten = []
        for sem in self.semester:
            for modul in sem.get_module():
                if modul.note is not None:
                    noten.append(modul.note)
        return round(sum(noten) / len(noten), 2) if noten else 0.0

    def calculate_fortschritt(self):
        total = 0
        for sem in self.semester:
            total += sem.calculate_fortschritt()
        return round(total / len(self.semester), 2) if self.semester else 0.0

    def get_klausurtermine(self):
        termine = []

        # Termine aus Modulen
        for sem in self.semester:
            for modul in sem.get_module():
                for klausur in getattr(modul, 'klausuren', []):
                    termine.append(f"{klausur.datum} | Status: {klausur.status}")

        # Manuell gesetzte Demo-Termine
        for termin in self.klausurtermine:
            if isinstance(termin, str):  # Nur das Datum
                termine.append(f"{termin} | Status: Nicht angemeldet")

        return termine
