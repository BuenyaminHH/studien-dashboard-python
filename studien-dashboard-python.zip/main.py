import tkinter as tk
from tkinter import ttk
from dashboard import Dashboard
from datenverwaltung import Datenverwaltung
from student import Student
from semester import Semester
from modul import Modul
from klausur import Klausur

# Dummy-Daten für das Dashboard
def erstelle_demo_dashboard():
    student = Student("Max Mustermann", "1234566", "Angewandte Künstliche Intelligenz", "12.02.2024 – 12.02.2027")

    semester1 = Semester("Semester 1", "12.02.2024", "12.08.2024")
    module1 = [
        Modul("Artificial Intelligence", "Bestanden", 2.0, "Klausur", 5),
        Modul("Einführung in das wissenschaftliche Arbeiten", "Angemeldet", None, "Workbook", 5),
        Modul("Einführung in die Programmierung mit Python", "Bestanden", 2.7, "Klausur", 5),
        Modul("Mathematik: Analysis", "Angemeldet", None, "Klausur", 5),
        Modul("Kollaboratives Arbeiten", "Angemeldet", None, "Präsentation", 5),
        Modul("Statistik – deskriptive Statistik", "Angemeldet", None, "Workbook", 5)
    ]

    # Dummy-Klausurtermine (werden manuell ins Dashboard gesetzt)
    klausurtermine = ["09.03.2024", "23.03.2024", "06.04.2024", "20.04.2024", "04.05.2024"]

    for modul in module1:
        semester1.add_modul(modul)

    dashboard = Dashboard(student)
    dashboard.add_semester(semester1)
    dashboard.klausurtermine = klausurtermine  # für Anzeige in der GUI
    return dashboard

# GUI Klasse
class DashboardGUI:
    def __init__(self, root, dashboard):
        self.root = root
        self.dashboard = dashboard
        self.root.title("Studien-Dashboard")
        self.root.geometry("1000x500")

        self.setup_gui()

    def setup_gui(self):
        # Kopfbereich
        header = tk.Label(self.root, text=f"{self.dashboard.student.studiengang} (B.Sc.)\n{self.dashboard.student.name} | {self.dashboard.student.studienzeitraum}",
                          font=("Arial", 12), pady=10)
        header.pack()

        # Hauptbereich
        content = tk.Frame(self.root)
        content.pack(padx=20, pady=10, fill="both", expand=True)

        # Linke Seite: Semester + Module
        left_frame = tk.Frame(content)
        left_frame.pack(side="left", fill="y", padx=10)

        self.semester_var = tk.StringVar()
        self.semester_auswahl = ttk.Combobox(left_frame, textvariable=self.semester_var)
        self.semester_auswahl["values"] = [s.name for s in self.dashboard.semester]
        self.semester_auswahl.current(0)
        self.semester_auswahl.bind("<<ComboboxSelected>>", self.update_module_liste)
        self.semester_auswahl.pack()

        self.module_box = tk.Text(left_frame, height=15, width=60, font=("Courier New", 10), wrap="none")
        self.module_box.pack()

        # Rechte Seite: Fortschritt + Noten + Klausurtermine
        right_frame = tk.Frame(content)
        right_frame.pack(side="right", fill="y", padx=10)

        # Fortschritt
        fortschritt = self.dashboard.calculate_fortschritt()
        fortschritt_label = tk.Label(right_frame, text=f"Studienfortschritt: {fortschritt:.2f}%")
        fortschritt_label.pack()

        progress = ttk.Progressbar(right_frame, length=200, mode="determinate", maximum=100)
        progress["value"] = fortschritt
        progress.pack(pady=5)

        # Notenschnitt
        schnitt = self.dashboard.calculate_notendurchschnitt()
        noten_label = tk.Label(right_frame, text=f"Notendurchschnitt: {schnitt:.2f}", font=("Arial", 12, "bold"))
        noten_label.pack(pady=10)

        # Klausurtermine
        klausur_label = tk.Label(right_frame, text="Klausurtermine:")
        klausur_label.pack()

        klausur_box = tk.Listbox(right_frame, height=6, width=40)
        for termin in self.dashboard.get_klausurtermine():
            klausur_box.insert(tk.END, termin)
        klausur_box.pack()

        self.update_module_liste()

    def update_module_liste(self, event=None):
        self.module_box.delete("1.0", tk.END)
        semestername = self.semester_var.get()
        semester = next((s for s in self.dashboard.semester if s.name == semestername), None)
        if semester:
            for modul in semester.module:
                note = f"{modul.note:.1f}" if modul.note is not None else "-"
                zeile = f"{modul.name:<55} | Status: {modul.status:<10} | Note: {note:<4} | {modul.pruefungsart:<12} | {modul.ects:>2} ECTS"
                self.module_box.insert(tk.END, zeile + "\n")

# Start der Anwendung
if __name__ == "__main__":
    dashboard = erstelle_demo_dashboard()
    root = tk.Tk()
    gui = DashboardGUI(root, dashboard)
    root.mainloop()
