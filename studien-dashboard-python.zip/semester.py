from modul import Modul

class Semester:
    """
    Repräsentiert ein Studiensemester mit mehreren Modulen.
    """

    def __init__(self, name, startdatum, enddatum):
        self.name = name
        self.startdatum = startdatum
        self.enddatum = enddatum
        self.module = []  # 1:n Beziehung zu Modul

    def add_modul(self, modul: Modul):
        self.module.append(modul)

    def get_module(self):
        return self.module

    def calculate_fortschritt(self):
        bestandene = sum(1 for modul in self.module if modul.ist_bestanden())
        return round((bestandene / len(self.module)) * 100, 2) if self.module else 0.0
