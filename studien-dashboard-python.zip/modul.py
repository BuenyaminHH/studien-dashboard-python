# modul.py

from klausur import Klausur

class Modul:
    """
    Repräsentiert ein Studienmodul mit zugehöriger Prüfungsleistung.
    """

    def __init__(self, name, status, note=None, pruefungsart=None, ects=5):
        self.name = name
        self.status = status
        self.note = note
        self.pruefungsart = pruefungsart
        self.ects = ects
        self.klausuren = []  # 1:n Beziehung zu Klausur

    def add_klausur(self, klausur: Klausur):
        self.klausuren.append(klausur)

    def get_note(self):
        return self.note

    def ist_bestanden(self):
        return self.status == "Bestanden"
