import json

class Datenverwaltung:
    """
    Klasse zum Speichern und Laden von Dashboard-Daten.
    """

    def speichern(self, daten, dateiname="daten.json"):
        with open(dateiname, "w") as f:
            json.dump(daten, f)

    def laden(self, dateiname="daten.json"):
        try:
            with open(dateiname, "r") as f:
                return json.load(f)
        except FileNotFoundError:
            return {}