class Student:
    """
    Repräsentiert einen Studenten mit persönlichen Informationen.
    """

    def __init__(self, name, matrikelnummer, studiengang, studienzeitraum):
        self.name = name
        self.matrikelnummer = matrikelnummer
        self.studiengang = studiengang
        self.studienzeitraum = studienzeitraum

    def __str__(self):
        return f"{self.name} | {self.studienzeitraum}"