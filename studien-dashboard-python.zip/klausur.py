# klausur.py

class Klausur:
    """
    Repräsentiert eine einzelne Prüfungsleistung (z. B. Klausur) in einem Modul.
    """

    def __init__(self, datum, status="Nicht angemeldet"):
        self.datum = datum
        self.status = status

    def anmelden(self):
        self.status = "Angemeldet"